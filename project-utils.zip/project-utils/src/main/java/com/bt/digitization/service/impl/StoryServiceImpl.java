package com.bt.digitization.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bt.digitization.domain.Story;
import com.bt.digitization.repository.StoryRepository;
import com.bt.digitization.service.StoryService;

@Service
public class StoryServiceImpl implements StoryService {

	@Autowired
	private StoryRepository storyRepo;
	
	@Override
	public void saveStory(Story story) {
		storyRepo.save(story);
	}
	
	@Override
	public Story getStoryById(Long id) {
		
		System.out.println(id);
		
		storyRepo.findAll().forEach(s -> System.out.println(s));
		
		Optional<Story> storyOpt = storyRepo.findById(id);
		
		if(storyOpt.isPresent()) {
			return storyOpt.get();
		} else {
			return null;
		}
		
	}
	
}
