package com.bt.digitization.controller;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.bt.digitization.domain.Component;
import com.bt.digitization.domain.Development;
import com.bt.digitization.domain.Employee;
import com.bt.digitization.domain.Story;
import com.bt.digitization.domain.command.ComponentCommand;
import com.bt.digitization.domain.command.ReleaseCommand;
import com.bt.digitization.domain.converter.ComponentToComponentCommand;
import com.bt.digitization.domain.converter.ReleaseCommandToRelease;
import com.bt.digitization.domain.converter.ReleaseToReleaseCommand;
import com.bt.digitization.service.ComponentService;
import com.bt.digitization.service.DevelopmentService;
import com.bt.digitization.service.EmployeeService;
import com.bt.digitization.service.ReleaseService;
import com.bt.digitization.service.RoleService;
import com.bt.digitization.service.StoryService;

@Controller
public class MainController {
	
	@Autowired
	private RoleService roleService;
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private ReleaseService releaseService;
	@Autowired
	private ReleaseCommandToRelease releaseCtoRelease;
	@Autowired
	private ReleaseToReleaseCommand releaseToReleaseC;
	
	@Autowired
	private ComponentToComponentCommand cToCC;
	
	@Autowired
	private ComponentService componentService;
	
	@Autowired
	private StoryService storyService;
	
	@Autowired
	private DevelopmentService devService;
	
	@GetMapping("/login")
	public String test() {
		return "login";
	}

	
	@GetMapping("/employee/add")
	public String addEMployee(Model model) {
		System.out.println("Inside addEMployee");
		
		System.out.println("RoleList === "+roleService.getRoles());
		
		model.addAttribute("employee", new Employee());
		model.addAttribute("roleList", roleService.getRoles());
		return "addUser";
	}
	
	
	@PostMapping("/employee/save")
	public String saveEmployee(@ModelAttribute Employee employee) {
		
		System.out.println("employee ======= "+employee);
		employeeService.saveEmployee(employee);
		
		System.out.println("employee ======= saved");
		return "addUser";
	}
	
	
	@GetMapping("/release/add")
	public String addRelease(Model model) {
		
		model.addAttribute("release", new ReleaseCommand());
		return "addRelease";
		
	}
	
	
	@PostMapping("/release/save")
	public String saveRelease(@ModelAttribute ReleaseCommand release, Model model) {
		
		System.out.println("release ======= "+release);
		
		
		releaseService.saveRelease(releaseCtoRelease.convert(release));
		model.addAttribute("release", release);
		
		System.out.println("release ======= saved");
		return "addRelease";
	}
	
	
	
	@GetMapping("/story/add")
	public String addStory(Model model) {
		
		System.out.println("Release === "+releaseService.getAllRelease());
		
		model.addAttribute("designers", employeeService.findEmployeeByRole("Designer"));
		model.addAttribute("dhs", employeeService.findEmployeeByRole("Delivery Head"));
		model.addAttribute("releases",releaseService.getAllRelease());
		model.addAttribute("components", componentService.getAllComponents());
		
		model.addAttribute("story", new Story());
		
		return "addStory";
		
	}
	
	
	@PostMapping("/story/save")
	public String saveStory(@ModelAttribute Story story, Model model) {
		
		System.out.println("story ======= "+story);
		
		storyService.saveStory(story);
		
		System.out.println("story ======= saved");
		
		return "redirect:/story/add";
	}
	
	
	@GetMapping("/story/view/{id}")
	public String viewStoryDetails(@PathVariable Long id, Model model) {
		System.out.println("Inside viewStoryDetails().");
		Story story = storyService.getStoryById(id);
		
		Set<Component> components = story.getComponents();
		
		Set<ComponentCommand> componentCommands = new HashSet<>();
		
		components.forEach(c -> componentCommands
					.add(cToCC.convert(c, story, devService.getDevDetailsByStoryIdAndComponentId(id, c.getId()), null)));
		
		System.out.println("-----------------"+story);
		
		model.addAttribute("story", story);
		model.addAttribute("componentCommands", componentCommands);
		return "storyDetailView";
	}
	
	@GetMapping("/story/{storyId}/component/{componentId}/{componentName}/development")
	public String addDevelopment(@PathVariable Long storyId, @PathVariable Long componentId, @PathVariable String componentName, Model model) {
		
		Story story = storyService.getStoryById(storyId);
		model.addAttribute("story", story);
		model.addAttribute("componentId", componentId);
		model.addAttribute("componentName", componentName);
		model.addAttribute("development", new Development());
		
		
		return "development";
	}
	
	@PostMapping("/story/{storyId}/component/{componentId}/development/save")
	public String saveDevelopment(@PathVariable Long storyId, @PathVariable Long componentId, 
			@ModelAttribute Development development, Model model) {
		
		System.out.println("Development === "+development);
		
		return "development";
	}
	
	

}
