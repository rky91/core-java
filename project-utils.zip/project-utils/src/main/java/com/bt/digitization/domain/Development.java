package com.bt.digitization.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToOne;

@Entity
public class Development {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private Date startDate;
	private Date endDate;
	private Date deliveryDate;
	private String status;
	private String unitTestStatus;
	private String componentDesignStatus;
	private String devServer;
	private String deployedPath;
	
	@Lob
	private String comments;
	@OneToOne
	private Employee designer;
	
	private Long storyId;
	private Long componentId;
	
	
	

	public Development() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUnitTestStatus() {
		return unitTestStatus;
	}

	public void setUnitTestStatus(String unitTestStatus) {
		this.unitTestStatus = unitTestStatus;
	}

	public String getComponentDesignStatus() {
		return componentDesignStatus;
	}

	public void setComponentDesignStatus(String componentDesignStatus) {
		this.componentDesignStatus = componentDesignStatus;
	}

	public String getDevServer() {
		return devServer;
	}

	public void setDevServer(String devServer) {
		this.devServer = devServer;
	}

	public String getDeployedPath() {
		return deployedPath;
	}

	public void setDeployedPath(String deployedPath) {
		this.deployedPath = deployedPath;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Employee getDesigner() {
		return designer;
	}

	public void setDesigner(Employee designer) {
		this.designer = designer;
	}

	public Long getStoryId() {
		return storyId;
	}

	public void setStoryId(Long storyId) {
		this.storyId = storyId;
	}

	public Long getComponentId() {
		return componentId;
	}

	public void setComponentId(Long componentId) {
		this.componentId = componentId;
	}
	
	

}
