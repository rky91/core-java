package com.bt.digitization.service;

import com.bt.digitization.domain.Releases;

public interface ReleaseService {

	void saveRelease(Releases release);

	Iterable<Releases> getAllRelease();

}
