package com.bt.digitization.repository;

import org.springframework.data.repository.CrudRepository;

import com.bt.digitization.domain.Releases;

public interface ReleaseRepository extends CrudRepository<Releases, Long>{
	
	

}
