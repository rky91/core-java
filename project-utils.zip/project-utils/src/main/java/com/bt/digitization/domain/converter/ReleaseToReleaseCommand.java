package com.bt.digitization.domain.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.bt.digitization.domain.Releases;
import com.bt.digitization.domain.command.ReleaseCommand;
import com.bt.digitization.util.Utils;

@Component
public class ReleaseToReleaseCommand implements Converter<Releases, ReleaseCommand> {

	@Override
	public ReleaseCommand convert(Releases source) {
		
		if(source != null) {
			
			ReleaseCommand rc = new ReleaseCommand();
			rc.setId(source.getId());
			rc.setName(source.getName());
			rc.setStartDate(Utils.getFormttedDate(source.getStartDate()));
			rc.setEndDate(Utils.getFormttedDate(source.getEndDate()));
			rc.setStories(source.getStories());
			rc.setStatus(source.getStatus());
			return rc;
			
		} else {
			return null;
		}
	}
}
