package com.bt.digitization.repository;

import org.springframework.data.repository.CrudRepository;

import com.bt.digitization.domain.Story;

public interface StoryRepository extends CrudRepository<Story, Long> {

}
