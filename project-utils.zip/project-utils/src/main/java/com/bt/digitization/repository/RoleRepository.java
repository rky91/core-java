package com.bt.digitization.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.bt.digitization.domain.Role;

public interface RoleRepository extends CrudRepository<Role, Long> {
	
	
	List<Role> findByName(String name);
}
