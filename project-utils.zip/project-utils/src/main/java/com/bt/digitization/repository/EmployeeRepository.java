package com.bt.digitization.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.repository.CrudRepository;

import com.bt.digitization.domain.Employee;
import com.bt.digitization.domain.Role;

public interface EmployeeRepository extends CrudRepository<Employee, Long> {
	
	List<Employee> findByRole(Set<Role> role);

}
