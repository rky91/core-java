package com.bt.digitization.repository;

import org.springframework.data.repository.CrudRepository;

import com.bt.digitization.domain.Component;

public interface ComponentRepository extends CrudRepository<Component, Long>{

}
