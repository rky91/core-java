package com.bt.digitization.service;

import com.bt.digitization.domain.Development;

public interface DevelopmentService {

	Development getDevDetailsByStoryIdAndComponentId(Long storyId, Long componentId);

}
