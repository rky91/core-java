package com.bt.digitization.domain;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Employee {
	
	@Id
	private Long ein;
	private String name;
	private String phoneNo;
	private String email;
	
	
	@ManyToMany
	@JoinTable(name = "employee_role",joinColumns = {@JoinColumn(name = "employee_id")}, inverseJoinColumns = {@JoinColumn(name = "role_id")})
	private Set<Role> role;
	
	

	public Employee() {
	}

	public Long getEin() {
		return ein;
	}

	public void setEin(Long ein) {
		this.ein = ein;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public Set<Role> getRole() {
		return role;
	}

	public void setRole(Set<Role> role) {
		this.role = role;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee [ein=" + ein + ", name=" + name + ", phoneNo=" + phoneNo + ", email=" + email  + "]";
	}
	
	
	
	

}
