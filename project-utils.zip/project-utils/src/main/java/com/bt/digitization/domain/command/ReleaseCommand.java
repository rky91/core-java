package com.bt.digitization.domain.command;

import java.util.Set;
import com.bt.digitization.domain.Story;

public class ReleaseCommand {
	
	
	private Long id;
	private String name;
	private String startDate;
	private String endDate;
	private Set<Story> stories;
	private String status;
	
	public ReleaseCommand() {}
	
	public ReleaseCommand(Long id, String name, String startDate, String endDate, Set<Story> stories, String status) {
		super();
		this.id = id;
		this.name = name;
		this.startDate = startDate;
		this.endDate = endDate;
		this.stories = stories;
		this.setStatus(status);
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Set<Story> getStories() {
		return stories;
	}
	public void setStories(Set<Story> stories) {
		this.stories = stories;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	

}
