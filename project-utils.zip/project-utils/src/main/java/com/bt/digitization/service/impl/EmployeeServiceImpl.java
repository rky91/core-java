package com.bt.digitization.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bt.digitization.domain.Employee;
import com.bt.digitization.domain.Role;
import com.bt.digitization.repository.EmployeeRepository;
import com.bt.digitization.service.EmployeeService;
import com.bt.digitization.service.RoleService;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	
	@Autowired
	private EmployeeRepository empRepo;
	@Autowired
	private RoleService roleService;
	
	@Override
	public void saveEmployee(Employee emp) {
		empRepo.save(emp);
	}
	
	@Override
	public Iterable<Employee> findAllEMployees(){
		
		empRepo.findAll().forEach(e -> System.out.println(e));
		return empRepo.findAll();
	}
	
	@Override
	public Set<Employee> findEmployeeByRole(String role){
		
		List<Role> roleList = roleService.findRoleByName(role);

		Set<Employee> empSet = new HashSet<>();
		roleList.forEach( r -> {
			empSet.addAll(r.getEmployee());
		});
		
		return empSet;
	}
}
