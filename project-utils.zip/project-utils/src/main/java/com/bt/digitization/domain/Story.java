package com.bt.digitization.domain;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Story {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private String stromId;
	private String ceStoryId;
	private String e2eSprint;
	private Long storyPoint;
	private Long tcsCost;
	private Long stromCost;
	private String status;
	
	@Lob
	private String comments;
	

	@OneToOne
	private Employee designer;
	@OneToOne
	private Employee owner;
	
	
	@ManyToOne
	@JoinColumn(name="release_id")
	private Releases release;
	
	@ManyToMany
	@JoinTable(name = "story_component",
		joinColumns = { @JoinColumn(name = "story_id") }, 
		inverseJoinColumns = { @JoinColumn(name = "component_id") })
	private Set<Component> components;
	

	public Story() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStromId() {
		return stromId;
	}

	public void setStromId(String stromId) {
		this.stromId = stromId;
	}

	public String getCeStoryId() {
		return ceStoryId;
	}

	public void setCeStoryId(String ceStoryId) {
		this.ceStoryId = ceStoryId;
	}

	public String getE2eSprint() {
		return e2eSprint;
	}

	public void setE2eSprint(String e2eSprint) {
		this.e2eSprint = e2eSprint;
	}

	public Long getStoryPoint() {
		return storyPoint;
	}

	public void setStoryPoint(Long storyPoint) {
		this.storyPoint = storyPoint;
	}

	public Long getTcsCost() {
		return tcsCost;
	}

	public void setTcsCost(Long tcsCost) {
		this.tcsCost = tcsCost;
	}

	public Long getStromCost() {
		return stromCost;
	}

	public void setStromCost(Long stromCost) {
		this.stromCost = stromCost;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Releases getRelease() {
		return release;
	}

	public void setRelease(Releases release) {
		this.release = release;
	}

	public Set<Component> getComponents() {
		return components;
	}

	public void setComponents(Set<Component> components) {
		this.components = components;
	}

	public Employee getDesigner() {
		return designer;
	}

	public Employee getOwner() {
		return owner;
	}

	public void setOwner(Employee owner) {
		this.owner = owner;
	}

	public void setDesigner(Employee designer) {
		this.designer = designer;
	}

	@Override
	public String toString() {
		return "Story [id=" + id + ", stromId=" + stromId + ", ceStoryId=" + ceStoryId + ", e2eSprint=" + e2eSprint
				+ ", storyPoint=" + storyPoint + ", tcsCost=" + tcsCost + ", stromCost=" + stromCost + ", status="
				+ status + ", comments=" + comments + ", designer=" + designer + ", owner=" + owner + ", release="
				+ release + ", components=" + components + "]";
	}
	
}
