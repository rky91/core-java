package com.bt.digitization.enumproperties;

public enum Status {
	
	
	CREATED,
	WIP,
	HOLD,
	COMPLETED,
	LIVE

}
