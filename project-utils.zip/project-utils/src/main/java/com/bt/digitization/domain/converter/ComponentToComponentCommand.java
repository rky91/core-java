package com.bt.digitization.domain.converter;

import org.springframework.core.convert.converter.Converter;

import com.bt.digitization.domain.Component;
import com.bt.digitization.domain.Development;
import com.bt.digitization.domain.Story;
import com.bt.digitization.domain.Testing;
import com.bt.digitization.domain.command.ComponentCommand;

@org.springframework.stereotype.Component
public class ComponentToComponentCommand implements Converter<Component, ComponentCommand> {

	@Override
	public ComponentCommand convert(Component source) {
		
		return null;
	}
	
	public ComponentCommand convert(Component s, Story story, Development development, Testing testing) {
		
		if(s != null) {
			
			ComponentCommand cc = new ComponentCommand();
			cc.setId(s.getId());
			cc.setName(s.getName());
			cc.setDevelopment(development);
			cc.setTesting(testing);
			cc.setStory(story);
			return cc;
			
		} else {
			return null;
		}
		
	}

}
