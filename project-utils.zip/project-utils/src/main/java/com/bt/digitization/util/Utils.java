package com.bt.digitization.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

public class Utils {
	
	public static String getFormttedDate(Date date) {
		
		LocalDate ldt = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		
		return DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH).format(ldt);
		
	}
	
	
	public static Date getDateFromString(String dateStr) {
		
		Date date;
		try {
			
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
			date = format.parse(dateStr);
			
	        return date;
	        
	        
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
        
		
		
	}

}
