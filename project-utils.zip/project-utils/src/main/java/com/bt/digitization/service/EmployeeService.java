package com.bt.digitization.service;

import java.util.List;
import java.util.Set;

import com.bt.digitization.domain.Employee;
import com.bt.digitization.domain.Role;

public interface EmployeeService{

	void saveEmployee(Employee emp);

	Iterable<Employee> findAllEMployees();

	Set<Employee> findEmployeeByRole(String role);

}
