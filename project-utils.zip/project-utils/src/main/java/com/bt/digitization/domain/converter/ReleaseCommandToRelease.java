package com.bt.digitization.domain.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.bt.digitization.domain.Releases;
import com.bt.digitization.domain.command.ReleaseCommand;
import com.bt.digitization.util.Utils;

@Component
public class ReleaseCommandToRelease implements Converter<ReleaseCommand, Releases> {

	@Override
	public Releases convert(ReleaseCommand source) {
		
		if(source != null) {
			
			Releases rc = new Releases();
			rc.setId(source.getId());
			rc.setName(source.getName());
			rc.setStartDate(Utils.getDateFromString(source.getStartDate()));
			rc.setEndDate(Utils.getDateFromString(source.getEndDate()));
			rc.setStories(source.getStories());
			rc.setStatus(source.getStatus());
			return rc;
			
		} else {
			return null;
		}
	}

}
