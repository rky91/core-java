package com.bt.digitization.service;

import com.bt.digitization.domain.Story;

public interface StoryService {

	void saveStory(Story story);

	Story getStoryById(Long id);

}
