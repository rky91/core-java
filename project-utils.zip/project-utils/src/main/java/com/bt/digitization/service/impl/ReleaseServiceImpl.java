package com.bt.digitization.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bt.digitization.domain.Releases;
import com.bt.digitization.repository.ReleaseRepository;
import com.bt.digitization.service.ReleaseService;

@Service
public class ReleaseServiceImpl implements ReleaseService {
	
	
	@Autowired
	private ReleaseRepository releaseRepo;
	
	
	@Override
	public void saveRelease(Releases release) {
		
		releaseRepo.save(release);
	}
	
	@Override
	public Iterable<Releases> getAllRelease() {
		return releaseRepo.findAll();
	}

}
