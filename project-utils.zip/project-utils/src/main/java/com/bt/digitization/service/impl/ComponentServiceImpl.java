package com.bt.digitization.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bt.digitization.domain.Component;
import com.bt.digitization.repository.ComponentRepository;
import com.bt.digitization.service.ComponentService;


@Service
public class ComponentServiceImpl implements ComponentService {
	
	@Autowired
	private ComponentRepository componentRepo;
	
	
	@Override
	public Iterable<Component> getAllComponents() {
		return componentRepo.findAll();
	}

}
