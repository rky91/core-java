package com.bt.digitization.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.bt.digitization.domain.Development;

public interface DevelopmentRepository extends CrudRepository<Development, Long> {
	
	Optional<Development> findByStoryIdAndComponentId(Long storyId, Long componentId);

}
