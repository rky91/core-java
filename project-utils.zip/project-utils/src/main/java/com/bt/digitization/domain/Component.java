package com.bt.digitization.domain;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
public class Component {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private String name;
	
	@ManyToMany(mappedBy = "components",cascade=CascadeType.ALL)
	private Set<Story> stories;
	
	
	public Component() {
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Set<Story> getStories() {
		return stories;
	}
	public void setStories(Set<Story> stories) {
		this.stories = stories;
	}
	
	
	@Override
	public String toString() {
		return "Component [id=" + id + ", name=" + name + ", stories=" + stories.size()  + "]";
	}
	
}
