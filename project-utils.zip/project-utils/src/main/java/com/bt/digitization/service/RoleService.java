package com.bt.digitization.service;

import java.util.List;

import com.bt.digitization.domain.Role;

public interface RoleService {

	Iterable<Role> getRoles();

	List<Role> findRoleByName(String name);

}
