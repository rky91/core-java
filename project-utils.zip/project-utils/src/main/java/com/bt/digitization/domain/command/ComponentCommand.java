package com.bt.digitization.domain.command;

import com.bt.digitization.domain.Development;
import com.bt.digitization.domain.Story;
import com.bt.digitization.domain.Testing;

public class ComponentCommand {
	
	private Long id;
	private String name;
	private Development development;
	private Testing testing;
	private Story story;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Development getDevelopment() {
		return development;
	}
	public void setDevelopment(Development development) {
		this.development = development;
	}
	public Testing getTesting() {
		return testing;
	}
	public void setTesting(Testing testing) {
		this.testing = testing;
	}
	public Story getStory() {
		return story;
	}
	public void setStory(Story story) {
		this.story = story;
	}
	
	@Override
	public String toString() {
		return "ComponentCommand [id=" + id + ", name=" + name + ", development=" + development + ", testing=" + testing
				+ ", story=" + story + "]";
	}
	
	
}
