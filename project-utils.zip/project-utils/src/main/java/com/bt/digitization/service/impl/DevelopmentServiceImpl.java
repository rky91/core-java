package com.bt.digitization.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bt.digitization.domain.Development;
import com.bt.digitization.repository.DevelopmentRepository;
import com.bt.digitization.service.DevelopmentService;

@Service
public class DevelopmentServiceImpl implements DevelopmentService{
	
	@Autowired
	private DevelopmentRepository devRepo;
	
	@Override
	public Development getDevDetailsByStoryIdAndComponentId(Long storyId, Long componentId) {
		
		Optional<Development> development = devRepo.findByStoryIdAndComponentId(storyId, componentId);
		
		if(development.isPresent()) {
			System.out.println("Dev ====> "+ development.get());
			return development.get();
		} else {
			System.out.println("Dev is NUll.");
			return null;
		}
		
	}

}
