package com.bt.texttovoice.domain;

public class Company {
	
	private String name;
	private int netSale;
	private int netExpenditure;
	private int netProfit;
	private String month;
	
	public Company() {}
	
	public Company(String name, int netSale, int netExpenditure, int netProfit, String month) {
		super();
		this.name = name;
		this.netSale = netSale;
		this.netExpenditure = netExpenditure;
		this.netProfit = netProfit;
		this.month = month;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNetSale() {
		return netSale;
	}
	public void setNetSale(int netSale) {
		this.netSale = netSale;
	}
	public int getNetExpenditure() {
		return netExpenditure;
	}
	public void setNetExpenditure(int netExpenditure) {
		this.netExpenditure = netExpenditure;
	}
	public int getNetProfit() {
		return netProfit;
	}
	public void setNetProfit(int netProfit) {
		this.netProfit = netProfit;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	@Override
	public String toString() {
		return "Company [name=" + name + ", netSale=" + netSale + ", netExpenditure=" + netExpenditure + ", netProfit="
				+ netProfit + ", month=" + month + "]";
	}
	
	

}
