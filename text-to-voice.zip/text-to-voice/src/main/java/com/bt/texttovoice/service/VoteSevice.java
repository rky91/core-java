package com.bt.texttovoice.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.bt.texttovoice.domain.Vote;

@Service
public class VoteSevice {
	
	private List<Vote> voteList = new ArrayList<>();
	
	public List<Vote> getVoteList(){
		voteList = Arrays.asList(
					new Vote("BJP", 500),
					new Vote("APP", 200),
					new Vote("BJD", -100),
					new Vote("TMC", 240),
					new Vote("UPA", -20),
					new Vote("TMK", 300)
				);
		
		return voteList;
	}

}
