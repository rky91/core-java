/**
 * 
 */

function startReading(artyom) {

	var __OBJECTS = [];

	$('.data-btn').each(function () {
		__OBJECTS.push($(this));
	});

	var $card = __OBJECTS.shift();
	str = buttonClick($card, __OBJECTS, artyom);

}

function readSpecificPreSearch(artyom) {

	 $("input[id$='DiscountType']").each(function (i, el) {
         //It'll be an array of elements
     });
	
}


function stopReading(artyom) {
	artyom.shutUp();
	var totalObjectsInCollection = artyom.getGarbageCollection().length;
	// Clear now that there are no more text to say.
	artyom.clearGarbageCollection();
	console.log("The garbage collection has been cleaned. " + totalObjectsInCollection + " Items found. Now there are " + artyom.getGarbageCollection().length);
}


 function buttonClick(ele, __OBJECTS, artyom) {

	console.log('Inside buttonClick()****************************');
	var fired_button = ele.val();
	var str = 'Result of ';

	ele.addClass("btn-primary");

	$.ajax({
		type: 'GET',
		url: fired_button,
		success: function (result) {
			console.log(result);
			var success = true;

			for (var key in result) {
				if (result.hasOwnProperty(key)) {
					var val = result[key];
					console.log(val.name);
					if (success) {
						str = str + val.name + ', '
						success = false;
					}
					str = str + ', Month ' + val.month + ', '
						+ ' Net sale £' + val.netSale + ','
						+ ' Net Expenditure £' + val.netExpenditure + ',';

					if (val.netProfit < 0) {
						str = str + ' Net Loss £' + val.netProfit;
					} else {
						str = str + ' Net Profit £' + val.netProfit;
					}
				}
			}
			var labels = result.map(function (e) {
				return e.month;
			});
			var netProfit = result.map(function (e) {
				return e.netProfit;
			});

			var netSale = result.map(function (e) {
				return e.netSale;
			});

			var netExp = result.map(function (e) {
				return e.netExpenditure;
			});

			var ctx = document.getElementById("myChart");
			var myChart = new Chart(ctx, {
				type: 'bar',
				data: {
					labels: labels,
					datasets: [
						{
							label: 'Sale',
							data: netSale,
							backgroundColor: 'rgba(54, 162, 235, 0.2)',
							borderColor: 'rgba(54, 162, 235, 0.2)',
							borderWidth: 1
						},
						{
							label: 'Expenditure',
							data: netExp,
							backgroundColor: 'rgba(255, 102, 0, 0.5)',
							borderColor: 'rgba(255, 102, 0, 0.5)',
							borderWidth: 1
						},
						{
							label: 'Profit/Loss',
							data: netProfit,
							backgroundColor: 'rgba(0, 51, 0, 0.5)',
							borderColor: 'rgba(0, 51, 0, 0.5)',
							borderWidth: 1
						}

					]
				},
				options: {
					scales: {
						yAxes: [{
							ticks: {
								beginAtZero: true
							}
						}]
					},
					
					tooltips : {
						mode : 'nearest'
					},

					events: ['click']
				}
			});
		}
	});

	$(document).ajaxComplete(function () {
		 artyom.dontObey();
		 artyom.say(str, {

			 onEnd: function () {
				 ele.removeClass("btn-primary");
				 ele.addClass("btn-secondary");
				 str = 'Result of ';
				 var $card = __OBJECTS.shift();
				 str = buttonClick($card, __OBJECTS, artyom);
				 var totalObjectsInCollection = artyom.getGarbageCollection().length;
				 // Clear now that there are no more text to say.
				 artyom.clearGarbageCollection();
				 console.log("The garbage collection has been cleaned. " + totalObjectsInCollection + " Items found. Now there are " + artyom.getGarbageCollection().length);
			 }
		 });
	 });
 }


 function startArtyom() {

	 //const artyom = new Artyom();
	 artyom.initialize({
		 lang: "en-GB",// More languages are documented in the library
		 voice: "['Google UK English Female', 'Google UK English Male', 'en-GB', 'en_GB']",
		 continuous: true,//if you have https connection, you can activate continuous mode
		 debug: true,//Show everything in the console
		 listen: true, // Start listening when this function is triggered
		 obeyKeyword: "Prime"
	 });

	 
 }

 
 
 
 /* Specific Reading */
 
 function updateLisined(){
	 artyom.say("You have result for the companies BT, Openreach, EE and Vodafone." +
	        		 " Do you want me read for all or any specific?", {
		onEnd: function () {

		}

	 });
 }
 
 function specificLisined(){
	 artyom.say("For which company do you want me to read? BT, Openreach, EE or Vodafone", {
		onEnd: function () {

		}

	 });
 }
 
 function startreadingSpecific(ele, artyom) {

	console.log('Inside buttonClick()****************************'+ele.val());
	artyom.dontObey();
	var fired_button = ele.val();
	var str = 'Result of ';

	ele.addClass("btn-primary");

	$.ajax({
		type: 'GET',
		url: fired_button,
		success: function (result) {
			console.log(result);
			var success = true;

			for (var key in result) {
				if (result.hasOwnProperty(key)) {
					var val = result[key];
					console.log(val.name);
					if (success) {
						str = str + val.name + ', '
						success = false;
					}
					str = str + ', Month ' + val.month + ', '
						+ ' Net sale £' + val.netSale + ','
						+ ' Net Expenditure £' + val.netExpenditure + ',';

					if (val.netProfit < 0) {
						str = str + ' Net Loss £' + val.netProfit;
					} else {
						str = str + ' Net Profit £' + val.netProfit;
					}
				}
			}
			var labels = result.map(function (e) {
				return e.month;
			});
			var netProfit = result.map(function (e) {
				return e.netProfit;
			});

			var netSale = result.map(function (e) {
				return e.netSale;
			});

			var netExp = result.map(function (e) {
				return e.netExpenditure;
			});

			var ctx = document.getElementById("myChart");
			var myChart = new Chart(ctx, {
				type: 'bar',
				data: {
					labels: labels,
					datasets: [
						{
							label: 'Sale',
							data: netSale,
							backgroundColor: 'rgba(54, 162, 235, 0.2)',
							borderColor: 'rgba(54, 162, 235, 0.2)',
							borderWidth: 1
						},
						{
							label: 'Expenditure',
							data: netExp,
							backgroundColor: 'rgba(255, 102, 0, 0.5)',
							borderColor: 'rgba(255, 102, 0, 0.5)',
							borderWidth: 1
						},
						{
							label: 'Profit/Loss',
							data: netProfit,
							backgroundColor: 'rgba(0, 51, 0, 0.5)',
							borderColor: 'rgba(0, 51, 0, 0.5)',
							borderWidth: 1
						}

					]
				},
				options: {
					scales: {
						yAxes: [{
							ticks: {
								beginAtZero: true
							}
						}]
					},
					
					tooltips : {
						mode : 'nearest'
					}
				}
			});
		}
	});

	$(document).ajaxComplete(function () {
		 
		 artyom.say(str, {

			 onEnd: function () {
				 ele.removeClass("btn-primary");
				 ele.addClass("btn-secondary");
				 str = 'Result of ';
				 var totalObjectsInCollection = artyom.getGarbageCollection().length;
				 // Clear now that there are no more text to say.
				 artyom.clearGarbageCollection();
				 console.log("The garbage collection has been cleaned. " + totalObjectsInCollection + " Items found. Now there are " + artyom.getGarbageCollection().length);
			 }
		 });
	 });
 }














